
export const colorGreyLight = '#F5F5F5';
export const colorBlackDark = '#000000'