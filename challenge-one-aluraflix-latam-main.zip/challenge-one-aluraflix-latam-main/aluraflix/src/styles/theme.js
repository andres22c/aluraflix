
const theme = {
    breakpoints: {
        mobile: '480px',
        tablet: '768px',
        laptop:'992px',
        desktop: '1024px',
      }



}



export default theme;