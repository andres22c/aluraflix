import React from 'react'

import styled , {css} from "styled-components"



const Title = styled.h1`
    background-color: #6BD1FF;
    color: red;
    
  `


const BannerText = () => {
  return (
    <div>
        
       <Title>BannerText</Title> 
        
        
        
        </div>
  )
}

export default BannerText