Challenge React curso Front End React Alura Latam


-Link a video demo del proyecto:https: https://www.youtube.com/watch?v=U6bFlJegzfo

-Link al proyecto alojado en vercel: https://aluraflix-phi-six.vercel.app/




![](aluraflix/fotos/foto1.jpg)

![](aluraflix/fotos/foto2.jpg)

![](aluraflix/fotos/foto3.jpg)

![](aluraflix/fotos/foto4.jpg)

![](aluraflix/fotos/foto5.jpg)

![](aluraflix/fotos/foto6.jpg)

![](aluraflix/fotos/foto7.jpg)